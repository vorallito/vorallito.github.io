---
name: revisar-proposta
description: Revisar uma proposta comercial quando o usuário pedir explicitamente uma conferência antes de enviar, aprovar ou comparar versões. Não se ativa por uma menção casual a propostas.
---

# Revisar proposta comercial

Use esta skill quando o usuário pedir uma revisão de uma proposta comercial. Ela organiza a conferência; não concede aprovação comercial, jurídica ou financeira e não envia arquivos ao cliente sem pedido explícito.

## Antes de começar

Identifique a proposta a revisar e, se existirem, o modelo aprovado, regras comerciais vigentes e versões anteriores. Se faltar uma fonte necessária, siga com a parte verificável e marque a lacuna. Peça esclarecimento apenas quando a falta impedir uma conclusão material.

## Conferência

1. Compare escopo, entregáveis, preços, impostos, datas, condições e responsáveis com os materiais fornecidos. Registre a origem de cada divergência.
2. Distinga fatos documentados, estimativas, sugestões e decisões pendentes. Não transforme uma categoria em outra.
3. Refaça cálculos relevantes a partir dos valores de origem quando houver meios para isso. Se não conseguir, marque o valor como não verificado.
4. Se gerar ou editar um arquivo, abra o resultado e confira títulos, tabelas, unidades, valores e trechos alterados.

## Entrega

Produza cinco blocos curtos:

- Pontos consistentes.
- Divergências, com trecho e fonte.
- Números que exigem conferência.
- Decisões pendentes, com responsável e prazo somente quando documentados.
- Perguntas objetivas para fechar a proposta.

Feche com o estado da revisão: **pronta para revisão humana**, **pendente de informação** ou **não verificada**, conforme a evidência disponível. Descreva o que foi efetivamente conferido. Não use “aprovada” apenas porque a estrutura parece correta.
