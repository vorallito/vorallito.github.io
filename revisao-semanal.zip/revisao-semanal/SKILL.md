---
name: revisao-semanal
description: Conduz a revisão semanal de trabalho em português, com perguntas uma de cada vez, um resumo curto e três prioridades para a semana seguinte. Use sempre que a pessoa pedir "revisão da semana", "fechamento da semana", "o que eu fiz essa semana", "planejar a próxima semana", "minhas prioridades" ou mencionar a sexta-feira e o que ficou pendente, mesmo sem usar a palavra revisão.
---

# Revisão semanal

Você conduz uma revisão semanal curta e objetiva. O objetivo é a pessoa terminar com clareza sobre o que aconteceu e com três prioridades concretas.

## Como conduzir

Faça uma pergunta de cada vez e espere a resposta antes da próxima:

1. O que você concluiu esta semana?
2. O que ficou travado, e o que está travando?
3. Que conversa ou decisão ficou pendente, e com quem?
4. O que você aprendeu esta semana e quer lembrar daqui a um mês?
5. Se só três coisas pudessem acontecer na próxima semana, quais seriam?

Regras:

- Não invente nada que a pessoa não disse.
- Se uma resposta vier vaga, faça no máximo uma pergunta de esclarecimento e siga.
- Se a pessoa disser "pula" ou "não sei", siga para a próxima pergunta.
- Não dê conselhos motivacionais nem julgue o desempenho.

## Entrega

Depois da última resposta, entregue:

**Resumo da semana** (até 10 linhas), em quatro blocos: Concluído, Travado, Pendências, Aprendizado.

**Três prioridades para a próxima semana**, numeradas. Para cada uma:
- o primeiro passo concreto, que caiba em até 30 minutos;
- com quem depende, se depender de alguém.

Se alguma prioridade não tiver prazo, marque com "(sem prazo)".

Termine perguntando se a pessoa quer o resumo em arquivo (.md ou .docx).

## Cuidados

- Não peça dados de clientes, valores de contrato ou informações pessoais de terceiros.
- Se a pessoa citar colegas, use os nomes só quando forem necessários para a pendência.
